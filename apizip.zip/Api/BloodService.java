package com.example.webusers.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webusers.modals.Blood;
import com.example.webusers.repositories.BloodRepository;

@Service
public class BloodService {

	@Autowired
	private BloodRepository bloodRepository;
	public Blood save(Blood blood) {
		
		return bloodRepository.save(blood);
	}
	
	public List<Blood> getAllBloodList(){
		
		return bloodRepository.findAll();
	}
}
