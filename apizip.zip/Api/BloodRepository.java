package com.example.webusers.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.webusers.modals.Blood;

@Repository
public interface BloodRepository extends CrudRepository<Blood, Long>{
	
	List<Blood> findAll();

}
