package com.example.webusers.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.webusers.modals.Blood;
import com.example.webusers.services.BloodService;



@Controller
@RequestMapping("blood")
public class BloodController {

private static final String VIEWS = "blood/";
	
	@Autowired
	private BloodService bloodService;
	
	@GetMapping("add")
	public String getBloodForm() {
		return VIEWS+"add-blood";
	}
	
	@PostMapping("submit")
	public String saveBlood(Blood blood,ModelAndView mv) {
		bloodService.save(blood);
		return "redirect:/blood";
	}
	
	@GetMapping("")
	public ModelAndView getBloodList(ModelAndView mv) {
		
		mv.setViewName(VIEWS+"blood-list");
		
		List<Blood> bloods = bloodService.getAllBloodList();
		
		mv.addObject("bloods",bloods);
		return mv;
}
}
