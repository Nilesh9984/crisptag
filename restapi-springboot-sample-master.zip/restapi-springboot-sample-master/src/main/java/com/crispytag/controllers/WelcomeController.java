package com.crispytag.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crispytag.modals.User;

@RestController
@RequestMapping("user")
public class WelcomeController {

	@GetMapping("get-sample")
	public User getSampleUser() {
		
		return new User("crispytag", "Crispy Tag", "28" , "India");
	}
	
	@GetMapping("get-sample-param/{username}")
	public User getSampleUser(@PathVariable("username") String username) {
		
		return new User(username, "Crispy Tag", "28" , "India");
	}
	
	@GetMapping("get-sample-param-query")
	public User getSampleUser(
			@RequestParam(name = "username", required = true) String username,
			@RequestParam(name = "name", required = false) String name,
			@RequestParam(name = "age", required = false) String age,
			@RequestParam(name = "country", required = false) String country) {
		
		return new User(username, name, age , country);
	}
}
